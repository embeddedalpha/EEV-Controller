Unserver is an HTTP/REST API for Modbus RTU and Modbus TCP protocol.

Please visit https://unserver.xyz/docs/ or https://unserver.xyz to learn more.

All Rights Reserved (c) 2017 Intellation Ltd. 